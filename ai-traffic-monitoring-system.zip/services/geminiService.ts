
import { GoogleGenAI } from "@google/genai";

const getTrafficPrediction = async (context: string): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
  }

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const prompt = `
      You are a sophisticated traffic analysis AI for a city's monitoring system. 
      Your task is to provide a traffic prediction for the 3 hours following the specified date and time.
      Be concise, professional, and provide actionable insights.

      Use the following simulation data to generate your prediction:
      ${context}

      Your response should include:
      1.  A brief, one-sentence summary of the overall prediction.
      2.  A bulleted list of key predictions (e.g., expected changes in volume, potential congestion spots, impact of weather).
      3.  A concluding remark or recommendation.

      Do not use markdown formatting like bold or italics.
    `;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt
    });

    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to fetch prediction from Gemini API.");
  }
};

export { getTrafficPrediction };
