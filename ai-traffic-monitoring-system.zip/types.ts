
export type VehicleType = 'Car' | 'Truck' | 'Bus' | 'Motorcycle';

export interface VehicleLogEntry {
  id: number;
  timestamp: Date;
  type: VehicleType;
}

export type WeatherCondition = 'Sunny' | 'Cloudy' | 'Rainy' | 'Foggy';

export interface ChartData {
  hour: string;
  vehicles: number;
}
