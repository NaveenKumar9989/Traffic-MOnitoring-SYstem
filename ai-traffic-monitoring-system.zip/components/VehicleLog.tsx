
import React from 'react';
import { VehicleLogEntry, VehicleType } from '../types';

const VehicleIcon = ({ type }: { type: VehicleType }) => {
  // FIX: Remove explicit JSX.Element type to fix "Cannot find namespace 'JSX'" error. Type is inferred.
  const iconMap = {
    Car: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-foam" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 2a1 1 0 011 1v1h4a1 1 0 011 1v1a1 1 0 01-1 1h-1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1V7h-1a1 1 0 01-1-1V5a1 1 0 011-1h4V3a1 1 0 011-1zm2 13a1 1 0 100 2 1 1 0 000-2zm-6 0a1 1 0 100 2 1 1 0 000-2z" clipRule="evenodd" /></svg>,
    Truck: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gold" viewBox="0 0 20 20" fill="currentColor"><path d="M4 4a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2V6a2 2 0 00-2-2H4zm0 2h10v6H4V6z" /><path d="M12 2a2 2 0 012 2v1h-2V4a2 2 0 012-2zM4 14a2 2 0 100 4 2 2 0 000-4z" /><path d="M14 14a2 2 0 100 4 2 2 0 000-4z" /></svg>,
    Bus: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-iris" viewBox="0 0 20 20" fill="currentColor"><path d="M2 5a2 2 0 012-2h12a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V5zm14 0H4v8h12V5zM3 15a1 1 0 112 0 1 1 0 01-2 0zm12 0a1 1 0 112 0 1 1 0 01-2 0z" /></svg>,
    Motorcycle: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-rose" viewBox="0 0 20 20" fill="currentColor"><path d="M18 6a2 2 0 11-4 0 2 2 0 014 0zM8 7a3 3 0 100-6 3 3 0 000 6zm4 8a3 3 0 100-6 3 3 0 000 6z" /><path d="M8 8a1 1 0 01-1.447-.894L4.43 3.63A1 1 0 016.32 3.2l.53.212a3.004 3.004 0 002.321.054L10 6.131V8H8z" /></svg>,
  };
  return iconMap[type];
};

interface VehicleLogProps {
  log: VehicleLogEntry[];
}

const VehicleLog: React.FC<VehicleLogProps> = ({ log }) => {
  return (
    <div className="space-y-3 h-[300px] overflow-y-auto pr-2">
      {log.length > 0 ? log.map((entry) => (
        <div key={entry.id} className="flex items-center space-x-4 p-2 rounded-lg bg-highlight-low">
          <div className="p-2 bg-highlight-med rounded-full">
            <VehicleIcon type={entry.type} />
          </div>
          <div className="flex-grow">
            <p className="font-medium text-text">{entry.type}</p>
            <p className="text-xs text-muted">{entry.timestamp.toLocaleTimeString()}</p>
          </div>
        </div>
      )) : (
        <div className="flex items-center justify-center h-full">
          <p className="text-muted">No recent vehicles detected.</p>
        </div>
      )}
    </div>
  );
};

export default VehicleLog;
