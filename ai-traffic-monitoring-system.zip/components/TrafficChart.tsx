
import React from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { ChartData } from '../types';

interface TrafficChartProps {
  data: ChartData[];
}

const TrafficChart: React.FC<TrafficChartProps> = ({ data }) => {
  return (
    <div style={{ width: '100%', height: 300 }}>
      <ResponsiveContainer>
        <BarChart data={data} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#333750" />
          <XAxis dataKey="hour" tick={{ fill: '#7f84a3' }} tickLine={{ stroke: '#7f84a3' }} />
          <YAxis tick={{ fill: '#7f84a3' }} tickLine={{ stroke: '#7f84a3' }} allowDecimals={false} />
          <Tooltip 
            contentStyle={{ 
                backgroundColor: '#1a1d2e', 
                borderColor: '#333750', 
                borderRadius: '0.75rem',
            }} 
            labelStyle={{ color: '#e0e1e6' }}
            itemStyle={{ color: '#b59fff' }}
          />
          <Bar dataKey="vehicles" fill="#b59fff" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default TrafficChart;
