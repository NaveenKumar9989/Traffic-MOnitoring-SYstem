
import React from 'react';
import { WeatherCondition } from '../types';

const WEATHER_CONDITIONS: WeatherCondition[] = ['Sunny', 'Cloudy', 'Rainy', 'Foggy'];

interface ControlPanelProps {
  date: string;
  time: string;
  weather: WeatherCondition;
  onDateChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onTimeChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onWeatherChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
}

const ControlPanel: React.FC<ControlPanelProps> = ({
  date,
  time,
  weather,
  onDateChange,
  onTimeChange,
  onWeatherChange,
}) => {
  return (
    <div className="bg-surface p-6 rounded-2xl shadow-lg border border-highlight-low flex flex-col sm:flex-row gap-6 items-center">
      <h2 className="text-xl font-bold text-text mb-4 sm:mb-0 whitespace-nowrap">Simulation Controls</h2>
      <div className="flex-grow grid grid-cols-1 sm:grid-cols-3 gap-4 w-full">
        <div>
          <label htmlFor="date-input" className="block text-sm font-medium text-muted mb-1">Date</label>
          <input
            id="date-input"
            type="date"
            value={date}
            onChange={onDateChange}
            className="w-full bg-base border border-highlight-med rounded-lg p-2 text-text focus:ring-iris focus:border-iris"
            aria-label="Select Date"
          />
        </div>
        <div>
          <label htmlFor="time-input" className="block text-sm font-medium text-muted mb-1">Time</label>
          <input
            id="time-input"
            type="time"
            value={time}
            onChange={onTimeChange}
            className="w-full bg-base border border-highlight-med rounded-lg p-2 text-text focus:ring-iris focus:border-iris"
            aria-label="Select Time"
          />
        </div>
        <div>
          <label htmlFor="weather-select" className="block text-sm font-medium text-muted mb-1">Climate</label>
          <select
            id="weather-select"
            value={weather}
            onChange={onWeatherChange}
            className="w-full bg-base border border-highlight-med rounded-lg p-2 text-text focus:ring-iris focus:border-iris appearance-none"
            style={{ backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%237f84a3' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e")`, backgroundPosition: 'right 0.5rem center', backgroundRepeat: 'no-repeat', backgroundSize: '1.5em 1.5em' }}
            aria-label="Select Climate"
          >
            {WEATHER_CONDITIONS.map(cond => (
              <option key={cond} value={cond}>{cond}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};

export default ControlPanel;
