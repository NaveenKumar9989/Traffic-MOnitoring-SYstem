
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
      <div>
        <h1 className="text-3xl font-bold text-text">Traffic Monitoring Dashboard</h1>
        <p className="text-muted">Real-time analysis and AI-powered predictions</p>
      </div>
    </header>
  );
};

export default Header;
