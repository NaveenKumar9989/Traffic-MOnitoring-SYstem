
import React, { ReactNode } from 'react';

interface StatCardProps {
  title: string;
  value: string;
  children: ReactNode;
  onClick?: () => void;
  isButton?: boolean;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, children, onClick, isButton = false }) => {
  const cardClasses = `bg-surface p-6 rounded-2xl shadow-lg flex items-center justify-between border border-highlight-low ${isButton ? 'cursor-pointer hover:bg-overlay transition-colors' : ''}`;

  return (
    <div className={cardClasses} onClick={onClick}>
      <div>
        <p className="text-sm text-muted">{title}</p>
        <p className="text-2xl font-bold text-text">{value}</p>
      </div>
      <div className="bg-highlight-med p-3 rounded-full">
        {children}
      </div>
    </div>
  );
};

export default StatCard;
