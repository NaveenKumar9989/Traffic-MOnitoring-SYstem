
import React, { useState, useEffect, useMemo, useCallback } from 'react';
// FIX: Import VehicleType to correctly type VEHICLE_TYPES constant.
import { VehicleLogEntry, WeatherCondition, ChartData, VehicleType } from './types';
import Header from './components/Header';
import StatCard from './components/StatCard';
import TrafficChart from './components/TrafficChart';
import VehicleLog from './components/VehicleLog';
import AIPrediction from './components/AIPrediction';
import ControlPanel from './components/ControlPanel';

// FIX: Add VehicleType[] to ensure type safety when creating new vehicle log entries.
const VEHICLE_TYPES: VehicleType[] = ['Car', 'Truck', 'Bus', 'Motorcycle'];
const WEATHER_CONDITIONS: WeatherCondition[] = ['Sunny', 'Cloudy', 'Rainy', 'Foggy'];

// Function to get current date as YYYY-MM-DD
const getTodayString = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = (today.getMonth() + 1).toString().padStart(2, '0');
    const day = today.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// Function to get current time as HH:MM
const getCurrentTimeString = () => {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
}

const WeatherIcon = ({ condition }: { condition: WeatherCondition }) => {
  // FIX: Remove explicit JSX.Element type to fix "Cannot find namespace 'JSX'" error. Type is inferred.
  const iconMap = {
    Sunny: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>,
    Cloudy: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-subtle" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" /></svg>,
    Rainy: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-iris" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15zm7-9l-1 4h2l-1 4" /></svg>,
    Foggy: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-muted" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M3 14h18M3 18h18" /></svg>
  };
  return iconMap[condition];
};

const App: React.FC = () => {
  const [vehicleLog, setVehicleLog] = useState<VehicleLogEntry[]>([]);
  const [weather, setWeather] = useState<WeatherCondition>('Sunny');
  const [selectedDate, setSelectedDate] = useState<string>(getTodayString());
  const [selectedTime, setSelectedTime] = useState<string>(getCurrentTimeString());

  // Use a stable seed based on the date for reproducible random data
  const generateDataForDate = useCallback((dateString: string) => {
    const seedDate = new Date(dateString);
    let seed = seedDate.getFullYear() * 10000 + (seedDate.getMonth() + 1) * 100 + seedDate.getDate();
    const random = () => {
        const x = Math.sin(seed++) * 10000;
        return x - Math.floor(x);
    };

    const initialDate = new Date(dateString);
    initialDate.setUTCHours(0, 0, 0, 0);
    const vehicleCount = 200 + Math.floor(random() * 300); // 200 to 500 vehicles
    const initialLogs: VehicleLogEntry[] = [];
    
    for(let i=0; i<vehicleCount; i++) {
        const hour = Math.floor(random() * 24);
        const minute = Math.floor(random() * 60);
        const second = Math.floor(random() * 60);
        const timestamp = new Date(initialDate);
        timestamp.setHours(hour, minute, second);

        initialLogs.push({
            id: timestamp.getTime() + random(),
            timestamp,
            type: VEHICLE_TYPES[Math.floor(random() * VEHICLE_TYPES.length)]
        });
    }
    setVehicleLog(initialLogs.sort((a,b) => b.timestamp.getTime() - a.timestamp.getTime()));
  }, []);

  useEffect(() => {
    generateDataForDate(selectedDate);
  }, [selectedDate, generateDataForDate]);

  const totalVehiclesOnDate = useMemo(() => {
    return vehicleLog.length;
  }, [vehicleLog]);
  
  const chartData = useMemo<ChartData[]>(() => {
    const hourlyCounts: { [hour: number]: number } = {};
    vehicleLog
      .forEach(v => {
        const hour = v.timestamp.getHours();
        hourlyCounts[hour] = (hourlyCounts[hour] || 0) + 1;
      });

    const data = Array.from({ length: 24 }, (_, i) => ({
      hour: `${i.toString().padStart(2, '0')}:00`,
      vehicles: hourlyCounts[i] || 0,
    }));
    return data;
  }, [vehicleLog]);
  
  const peakHour = useMemo(() => {
    if(chartData.length === 0) return 'N/A';
    const peak = chartData.reduce((max, current) => current.vehicles > max.vehicles ? current : max, chartData[0]);
    return peak.vehicles > 0 ? peak.hour : 'N/A';
  }, [chartData]);
  
  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedDate(e.target.value);
  };
  
  const handleTimeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedTime(e.target.value);
  };

  const handleWeatherChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setWeather(e.target.value as WeatherCondition);
  };

  return (
    <div className="min-h-screen bg-base p-4 sm:p-6 lg:p-8 font-sans">
      <div className="container mx-auto">
        <Header />
        
        <main className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
          <div className="col-span-1 md:col-span-2 lg:col-span-4">
              <ControlPanel 
                date={selectedDate}
                time={selectedTime}
                weather={weather}
                onDateChange={handleDateChange}
                onTimeChange={handleTimeChange}
                onWeatherChange={handleWeatherChange}
              />
          </div>
        
          <StatCard title={`Total Vehicles on ${new Date(selectedDate + 'T00:00:00').toLocaleDateString()}`} value={totalVehiclesOnDate.toString()}>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-rose" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v.01" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18V9m0 9c-1.657 0-3-.895-3-2s1.343-2 3-2 3-.895 3-2-1.343-2-3-2m0 8v1m0-1v-.01" /></svg>
          </StatCard>
          <StatCard title="Peak Traffic Hour" value={peakHour}>
             <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-foam" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          </StatCard>
          <StatCard title="Selected Climate" value={weather}>
              <WeatherIcon condition={weather} />
          </StatCard>
           <StatCard title="Data Status" value="Generated">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-pine" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          </StatCard>

          <div className="lg:col-span-3 md:col-span-2 bg-surface p-6 rounded-2xl shadow-lg border border-highlight-low">
            <h2 className="text-xl font-bold text-text mb-4">Hourly Vehicle Flow</h2>
            <TrafficChart data={chartData} />
          </div>
          
          <div className="lg:col-span-1 md:col-span-2 bg-surface p-6 rounded-2xl shadow-lg border border-highlight-low">
            <h2 className="text-xl font-bold text-text mb-4">Vehicle Log Sample</h2>
            <VehicleLog log={vehicleLog.slice(0, 10)} />
          </div>

          <div className="col-span-1 md:col-span-2 lg:col-span-4 bg-surface p-6 rounded-2xl shadow-lg border border-highlight-low">
             <AIPrediction
              weather={weather}
              totalVehicles={totalVehiclesOnDate}
              peakHour={peakHour}
              selectedDate={selectedDate}
              selectedTime={selectedTime}
            />
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
